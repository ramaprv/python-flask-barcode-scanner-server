from pymongo import MongoClient
from mongoengine import connect
from user import User, Account, Health
from mongoengine.queryset import Q
import datetime
from operator import attrgetter
from transaction import Transaction
from calendar import monthrange
import api

today = datetime.date.today()
thisMonth = datetime.date(day=1, month=today.month, year=today.year)
lastMonth = thisMonth - datetime.timedelta(days=29)
lastMonth = datetime.date(day=1, month=lastMonth.month, year=lastMonth.year)
twoMonthsBefore = lastMonth - datetime.timedelta(days=29)
twoMonthsBefore = datetime.date(day=1, month=twoMonthsBefore.month, year=twoMonthsBefore.year)

def fetchTransactionForUser(user):

    transactions = Transaction.objects(Q(user_id=str(user.id)) & Q(date__lte=today) & Q(date__gte = twoMonthsBefore))
    transDict = {}
    transDict[thisMonth] = []
    transDict[lastMonth] = []
    transDict[twoMonthsBefore] = []

    for trans in transactions:

        if  trans.date.month == thisMonth.month:
           transDict[thisMonth].append(trans)
        elif trans.date.month == lastMonth.month:
          transDict[lastMonth].append(trans)
        else :
          transDict[twoMonthsBefore].append(trans)

    return (transDict,transactions)

def approxEqual(trans1,trans2):
  #  print abs (trans1.date - trans2.date).days
  #  print abs(round(trans1.amount) - round(trans2.amount))

    if trans1.type == 0:
        print trans1.date.day - trans2.date.day
        print trans1.amount - trans2.amount
        print 'icomabs', abs (trans1.date.day - trans2.date.day) < 10 and abs((trans1.amount - trans2.amount)/trans1.amount * 100) < 10

    return abs (trans1.date.day - trans2.date.day) < 10 and abs((trans1.amount - trans2.amount)/trans1.amount * 100) < 10


def findRecurringTrans(trans_array1,trans_array2):
  trans1_array =[]
  trans2_array =[]

  for trans1 in trans_array1:
      for trans2 in trans_array2:
            if approxEqual(trans1,trans2):
               trans1_array.append(trans1)
               trans2_array.append(trans2)


	            #break

  return (trans1_array, trans2_array)


def returnForTransDict(transDict, month, type):
    transactions = []
    for trans in transDict[month]:
      if  trans.date.month == month.month and trans.type == type:
        transactions.append(trans)

    return transactions

def updateProfile(user):

    transDict,transactions= fetchTransactionForUser(user)

    map(lambda t:user.updateAccount(user, t), transactions)

    print transDict
    thisMonthCredits = returnForTransDict(transDict, thisMonth, 0)

    lastMonthCredits = returnForTransDict(transDict, lastMonth, 0)
    twoMonthsBeforeCredits = returnForTransDict(transDict, twoMonthsBefore, 0)
    print 'two monts',twoMonthsBeforeCredits,lastMonthCredits
    recurring_transactions = findRecurringTrans(lastMonthCredits,twoMonthsBeforeCredits)

    print 'recurring_transactions' , recurring_transactions
    if len(recurring_transactions[0])>0:
      transaction = max(recurring_transactions[0], key=attrgetter('amount')) if len(recurring_transactions[0])>0 else None
      print transaction.amount ,'amount'
      user.calculated_income = transaction.amount
      user.income_transaction_id = str(transaction.id)
      transaction.category = 'Salary'
      transaction.save()
    else:

          transaction = max(lastMonthCredits, key=attrgetter('amount')) if len(lastMonthCredits)>0 else None
          user.calculated_income = transaction.amount if transaction!= None else 0
          user.income_transaction_id = str(transaction.id) if transaction!= None else None
          if transaction !=None:
              transaction.category = 'Salary'
              transaction.save()
    thisMonthDebits = [ transaction for transaction in returnForTransDict(transDict, thisMonth, 1) if transaction.is_neft == True and (transaction.is_atm == False or transaction.is_atm == None) ]
    lastMonthDebits = [ transaction for transaction in returnForTransDict(transDict, lastMonth, 1) if transaction.is_neft == True and (transaction.is_atm == False or transaction.is_atm == None) ]
    twoMonthsBeforeDebits = [ transaction for transaction in  returnForTransDict(transDict, twoMonthsBefore, 1) if transaction.is_neft == True and (transaction.is_atm == False or transaction.is_atm == None) ]
    print 'lastmonthdebits' , lastMonthDebits , lastMonth , thisMonthDebits
    print 'twoMonthsBeforeDebits' , twoMonthsBeforeDebits ,twoMonthsBefore
    (expense1_transactions, expense2_transactions )= findRecurringTrans(lastMonthDebits,twoMonthsBeforeDebits)
    print expense1_transactions , 'ExpenTrnsabegore'

    for transaction in expense1_transactions:
        transaction.is_fixed = True
        transaction.save()
    print expense1_transactions , 'ExpenTrnsa'
    for transaction in expense2_transactions:
        transaction.is_fixed = True
        transaction.save()
    print expense1_transactions , 'EXP'


    for transaction in  findRecurringTrans(thisMonthDebits,expense1_transactions)[0]:
        transaction.is_fixed = True
        print 'this months trans' , transaction
        transaction.save()



    if len (expense1_transactions)>0:
        fixed_cost= sum(transaction.amount for transaction in expense1_transactions)
        user.fixed_cost_transactions_1 = [str(trans.id) for trans in expense1_transactions]
        user.calculated_fixed_cost = fixed_cost
    else:

        transaction = max(lastMonthDebits, key=attrgetter('amount')) if len(lastMonthDebits)>0 else None
        fixed_cost = transaction.amount if transaction != None else 0
        user.fixed_cost_transactions_1 = str(transaction.id) if transaction != None else None


    print fixed_cost, user.fixed
    user.calculated_fixed_cost = fixed_cost

    user.fixed_cost_transactions_1 = [str(trans.id) for trans in expense1_transactions]
    user.fixed_cost_transactions_2 = [str(trans.id) for trans in expense2_transactions]
    print 'fixed-trans1',   user.fixed_cost_transactions_1
    print 'Fixedamount', user.fixed
    user.income = 0 if user.income== None else user.income
    user.fixed = 0 if user.fixed== None else user.fixed
    user.updateHealthforUser(user,transactions)

    user.save()
