import mongoengine
from calendar import monthrange
from transaction import *
from decimal import Decimal
import calendar
import datetime
from mongoengine.django.auth import User

def getFloat(value):
    if value == None:
        return 0
    return float(value)

class Account(EmbeddedDocument):

        title = StringField(max_length=120, required=False)
        balance = DecimalField(required=False)
        type = IntField(required=False)

        def __dict__(self):
          return {'title':self.title, 'balance' : getFloat(self.balance), 'type' : self.type }

class Health(EmbeddedDocument):

        weekly_burn = FloatField(required=False)
        monthly_burn = FloatField(required=False)
        daily_burn = FloatField(required=False)
        monthly_spend_limit = FloatField(required=False)
        weekly_spend_limit = FloatField(required=False)
        daily_spend_limit = FloatField(required=False)
        monthly_spend = FloatField(required=False)
        weekly_spend = FloatField(required=False)
        daily_spend = FloatField(required=False)
        peer_monthly_burn = FloatField(required=False)
        peer_weekly_burn = FloatField(required=False)
        peer_daily_burn = FloatField(required=False)
        saving_percentile = FloatField(required=False)
        peer_text = StringField(required=False)

        def __dict__(self):
	         return { 'weeklyBurn' : self.weekly_burn,'monthlyBurn' : self.monthly_burn,'dailyBurn' : self.daily_burn,
		                'monthlySpend' : self.monthly_spend,'weeklySpend' : self.weekly_spend,'dailySpend' : self.daily_spend,
                    'monthlySpendLimit':self.monthly_spend_limit,'weeklySpendLimit':self.weekly_spend_limit,'dailySpendLimit':self.daily_spend_limit,
		                'peerMonthlyBurn' : self.peer_monthly_burn,'peerWeeklyBurn' : self.peer_weekly_burn,'peerDailyBurn' : self.peer_daily_burn,'savingPercentile':self.saving_percentile ,'peerText':self.peer_text}



class LongTermGoal(EmbeddedDocument):
      title = StringField(max_length=120, required=False)
      amount = DecimalField(required=False)
      months = DecimalField(required=False)
      percentage = DecimalField(required=False)
      created_date = DateTimeField(required=False)

      def __dict__(self):

         return { 'title':self.title,
                   'amount':getFloat(self.amount),
                   'months':getFloat(self.months),
                   'percentage':getFloat(self.percentage)
                   }








class User(Document):

        name = StringField(required=False)
        email = StringField(required=False)
        password = StringField(required=False)
        age = IntField(required=False)
        accounts = ListField(EmbeddedDocumentField(Account))
        health = EmbeddedDocumentField(Health)
        income = DecimalField(required=False)
        fixed = DecimalField(required=False)
        calculated_income =DecimalField(required=False)
        income_transaction_id = StringField(required=False)
        calculated_fixed_cost = DecimalField(required=False)
        fixed_cost_transactions_1  = ListField (StringField(),required = False)
        fixed_cost_transactions_2  = ListField (StringField(),required = False)
        savings_target = DecimalField(required=False)
        long_term_goals = EmbeddedDocumentField(LongTermGoal)
        image = StringField(required=False)
        device_id = StringField(required=False)
        accrue_balance = DecimalField(required=False)
        insight_date= DateTimeField(required=False)


        def __dict__(self):
            print 'income',self.income
            print 'fixed',self.fixed
            print 'calculated_income',self.calculated_income
            print 'calculated_fixed_cost',self.calculated_fixed_cost

            return {'name' : self.name,'email':self.email,'password':self.password,'age':self.age,'accounts':[account.__dict__() for account in self.accounts]
                   ,'income':getFloat(self.income) if self.income!=0 else getFloat(self.calculated_income),'fixedCost':getFloat(self.fixed) if self.fixed!=0 else getFloat(self.calculated_fixed_cost) ,'calculatedIncome':getFloat(self.calculated_income),
                   'calculatedFixedCost':getFloat(self.calculated_fixed_cost),'savingsTarget':getFloat(self.savings_target),'accrue_balance':getFloat(self.accrue_balance) if self.accrue_balance != None else getFloat(self.savings_target) ,
                   'longTermGoals': self.long_term_goals.__dict__() if self.long_term_goals !=None else None ,'health':self.health.__dict__() if self.health != None else None,'image':self.image,'deviceID':self.device_id}

        #    return {'name' : self.name,'email':self.email,'password':self.password,'age':self.age,'accounts':[account.__dict__() for account in self.accounts]
        #             ,'income':float(self.income) if self.income!=0 else float(290099.0),'fixedCost':float(self.fixed) if self.fixed!=0 else float(26826.46),'calculatedIncome':290099.0,
        #             'calculatedFixedCost':26826.46,'savingsTarget':30000.0,
        #             'longTermGoals': {'title':'Home','amount':40000000,'months':56},'health':{ 'weeklyBurn' : 0.5,'monthlyBurn' : 0.7,'dailyBurn' : 0.4,
        #                      'monthlySpend' : 26000,'weeklySpend' : 3000,'dailySpend' : 100,
        #                      'monthlySpendLimit':20000,'weeklySpendLimit':2000,'dailySpendLimit':80,
        #                      'peerMonthlyBurn' : 0.4,'peerWeeklyBurn' : 0.4,'peerDailyBurn' : 0.7 }}




        def calculate_accrue_balance(self,user,date):

            if date.day == 1:
                yesterday = date - datetime.timedelta(days = 1)
                days = calendar.monthrange(yesterday.year, yesterday.month)[1]

                first_day = date - datetime.timedelta(days = days)
                transactions = Transaction.objects(Q(user_id = str(user.id)) & Q(type=1) & Q(date__gte = first_day ) & Q(date__lt = yesterday) & Q(is_fixed = False))
                last_month_expense =  sum(transaction.amount for transaction in transactions)
                user.accrue_balance = getFloat(self.accrue_balance) + getFloat(self.available_funds())-getFloat(last_month_expense)
                user.save()




        def available_funds(self):

            income = self.income if self.income !=0 else self.calculated_income
            fixed = self.fixed if self.fixed != 0 else self.calculated_fixed_cost
            self.savings_target = 0 if self.savings_target == None else self.savings_target


            return getFloat(income) - getFloat(fixed) - getFloat(self.savings_target)

        def set_spend_limits(self,user):
            today = datetime.date.today()
            today =  datetime.date(day = today.day , month = today.month, year = today.year)
            yesterday = today - datetime.timedelta(days = 1)
            yesterday = datetime.date(day = yesterday.day , month = yesterday.month, year = yesterday.year)
            print ' yeste', yesterday , today

            days = calendar.monthrange(today.year, today.month)[1]
            last_day = datetime.date(day = days , month = today.month, year = today.year)
            first_day = datetime.date(day = 1 , month = today.month, year = today.year)
            first_weeknumber = first_day.isocalendar()[1]
            current_weekNumber = today.isocalendar()[1]
            last_weeknumber = last_day.isocalendar()[1]
            print 'Current Week , last week ', current_weekNumber , last_weeknumber
            print 'typesy' , type(first_day)
            remaining_weeks = (last_weeknumber - current_weekNumber) +1
            total_weeks =  (last_day.day-1)//7+1
            current_week = (today.day-1)//7+1
            print 'this weeks ', (current_week,total_weeks)

            remaining_days =  (last_day-today).days
            Transaction.objects()
            transactions = Transaction.objects(Q(user_id = str(user.id)) & Q(type=1) & Q(date__gte = first_day ) & Q(date__lte = today) & Q(is_fixed = False))
            print transactions , 'Fetched Transaction'
            totalMonthlyExpense = sum(transaction.amount for transaction in transactions)
            expense_till_today = sum (transaction.amount for transaction in transactions)
            expense_till_yesterday = sum (transaction.amount for transaction in transactions if transaction.date.date()>=first_day and transaction.date.date() < today )
            print [transaction for transaction in transactions if transaction.date.date() >= (self.week_start_date(today) - datetime.timedelta(days = 7)) and  transaction.date.date() < self.week_start_date(today)]
            expense_last_weeks = sum(transaction.amount for transaction in transactions if transaction.date.date() < self.week_start_date(today))
            print expense_last_weeks ,self.week_start_date(today),self.week_start_date(today) - datetime.timedelta(days = 7),'last-weeks'
            weekly_available  =  getFloat(user.available_funds())- getFloat(expense_last_weeks)
            weekly_limit = weekly_available / remaining_weeks
            weekly_burn =  getFloat(expense_last_weeks) / getFloat(weekly_limit) if expense_last_weeks and weekly_limit != 0 else 0
            print 'weekly values ', weekly_limit , weekly_available , remaining_weeks , weekly_burn
            this_week_expense = sum(transaction.amount for transaction in transactions if transaction.date.date() >= (self.week_start_date(today) - datetime.timedelta(days = 7)) and  transaction.date.date() <= today)

            daily_transactions = [transaction for transaction in transactions if transaction.date.date() > yesterday and transaction.date.date() <= today ]
            print 'daily' , daily_transactions
            totalDailyExpense = sum(transaction.amount for transaction in daily_transactions)
            user.health.daily_spend = float(totalDailyExpense)
            user.health.monthly_burn =float((float(totalMonthlyExpense)/float(user.available_funds()))) if totalMonthlyExpense !=0 and user.available_funds()!=0 else 0


            print 'expe', expense_till_today
            print 'user values', (getFloat(self.income),getFloat(self.savings_target),getFloat(expense_till_today))
            available_daily =   getFloat(user.available_funds())- getFloat(expense_till_yesterday)
            print 'ava_remain' , (available_daily,remaining_days)
            daily_limit = available_daily/(remaining_days if remaining_days >0 else 1 )
            this_week_limit =  available_daily/(total_weeks-current_week if current_week < total_weeks else 1 )
            #user.health.weekly_spend_limit = getFloat(weekly_limit)
            user.health.daily_spend_limit = getFloat(daily_limit)
            user.health.daily_burn = getFloat(totalDailyExpense) / getFloat(daily_limit)  if totalDailyExpense and daily_limit != 0 else 0
            user.health.weekly_burn = float(weekly_burn)
            user.health.weekly_spend = (getFloat(this_week_expense))
            user.health.weekly_spend_limit = getFloat(this_week_limit)
            user.health.monthly_spend = float(totalMonthlyExpense)
            user.health.monthly_burn =float((float(totalMonthlyExpense)/user.available_funds())) if totalMonthlyExpense !=0 and user.available_funds()!=0 else 0
            user.health.monthly_spend_limit = float(user.available_funds())



            self.calculate_accrue_balance(user,today)
            if user.long_term_goals != None :
                goal = user.long_term_goals
                print goal.amount , user.accrue_balance ,user.savings_target , 'accreBal'
                months = getFloat(goal.amount)  / getFloat(user.accrue_balance) if getFloat(user.accrue_balance) !=0 else getFloat(goal.amount)  / getFloat(user.savings_target)
                goal.percentage = (getFloat(goal.amount) /  getFloat(user.accrue_balance))*100 if getFloat(user.accrue_balance) != 0 else (getFloat(user.savings_target)  / getFloat(goal.amount))*100
                today = datetime.date.today()
                months  = months -  (today.month - goal.created_date.month)
                goal.months = getFloat(months)
                user.long_term_goals = goal




        def week_start_date(self,date):
            d = datetime.date(date.year, 1, 1)
            delta_days = d.isoweekday() - 1
            delta_weeks = date.isocalendar()[1]
            if date.year == d.isocalendar()[0]:
                delta_weeks -= 1
            delta = datetime.timedelta(days=-delta_days, weeks=delta_weeks)
            return d + delta




        def number_of_weeks(date):
            days = calendar.monthrange(date.year, date.month)[1]
            first =  datetime.date(day = 1 , month = date.month, year = date.year)
            last =  datetime.date(day = days , month = date.month, year = date.year)
            first_weeknumber = first.isocalendar()[1]
            last_weeknumber = last.isocalendar()[1]
            return (first_weeknumber - last_weeknumber) + 1



        def updateAccount(self, user, transaction):

            if self.accounts == None:
               self.accounts = []

            if transaction.accountTitle not in [account.title for account in self.accounts]:
                account = Account(title=transaction.accountTitle,
                                     type = transaction.accountType,
                                     balance = transaction.balance )
                self.accounts.append(account)
            else:
                for account in user.accounts:
                    if account.title == transaction.accountTitle:
                       account.balance = account.balance if transaction.balance == 0 else transaction.balance


        def updateHealthforUser(self, user, transactions):
              today = datetime.date.today()
              today =  datetime.date(day = today.day , month = today.month, year = today.year)
              yesterday = today - datetime.timedelta(days = 1)
              yesterday = datetime.date(day = yesterday.day , month = yesterday.month, year = yesterday.year)
              print ' yeste', yesterday , today
              thisMonth = datetime.date(day=1, month=today.month, year=today.year)
              if transactions==None:
                 transactions = Transaction.objects(user_id = user.id)
             # transactions = Transaction.objects(Q(user_id=str(user.id)) & Q(date__lte=today) & Q(date__gte = thisMonth) & Q(is_fixed__ne = True))
              #monthly_transactions = [transaction for transaction in transactions if transaction.type == 1 and transaction.date.month == today.month ]
             # print 'monthly',monthly_transactions
              #print 'availa',user.available_funds()

            #  daily_transactions = [transaction for transaction in monthly_transactions if transaction.date.date() >= yesterday and transaction.date.date() <= today ]
        #      print ' daily trans',daily_transactions
        #      weekly_transactions = [transaction for transaction in monthly_transactions if transaction.type == 1 and transaction.is_fixed != True  ]
        #      weekly_transactions = [transaction for transaction in monthly_transactions if transaction.type == 1 and
        #                              transaction.date >= (today - datetime.timedelta(days = today.weekday())) and transaction.date <= today ]

        #      print 'monthexp',totalMonthlyExpense
              user.health = Health()

            #  if getFloat(user.available_funds())<=0 or getFloat(totalMonthlyExpense) <=0  :
            #      user.health.monthly_burn =0
            #      user.health.daily_burn =0
            #      user.health.weekly_burn = 0
            #      print 'oh oh '

            #      return

        #      totalDailyExpense = sum(transaction.amount for transaction in daily_transactions)
        #      totalWeeklyExpense = sum(transaction.amount for transaction in weekly_transactions)
        #      user.health.monthly_burn =float((totalMonthlyExpense/user.available_funds())) if totalMonthlyExpense !=0 and user.available_funds()!=0 else 0
        #      user.health.daily_burn =float(totalDailyExpense/(user.available_funds()/monthrange(thisMonth.year, thisMonth.month)[1])) if totalDailyExpense !=0  else 0
             # user.health.weekly_burn = float((totalWeeklyExpense/(totalMonthlyExpense/4))) if totalWeeklyExpense !=0 and totalMonthlyExpense !=0 else 0
             # user.health.weekly_spend = float(totalWeeklyExpense)
        #      user.health.daily_spend = float(totalDailyExpense)
        #      user.health.monthly_spend = float(totalMonthlyExpense)
        #      user.health.monthly_spend_limit = float(user.available_funds())
              self.set_spend_limits(user)
             # user.health.weekly_spend_limit = float(user.available_funds()/4)
             # user.health.daily_spend_limit = float((user.available_funds()/monthrange(thisMonth.year, thisMonth.month)[1]))
             # print user.health.monthly_burn
             #print 'age',user.age
              #remove during production


             # return
              users_monthly_burn_avg =User.objects(Q(age__lte= user.age+3) & Q(age__gte = user.age-3) & Q(health__ne = None) & Q(age__ne = None)) .average('health.monthly_burn')
              users_weekly_burn_avg =User.objects(Q(age__lte= user.age+3) & Q(age__gte = user.age-3)) .average('health.weekly_burn')
              users_daily_burn_avg =User.objects(Q(age__lte= user.age+3) & Q(age__gte = user.age-3)) .average('health.daily_burn')
              user.health.peer_monthly_burn = float(users_monthly_burn_avg)
              user.health.peer_weekly_burn = float(users_weekly_burn_avg)
              user.health.peer_daily_burn = float(users_daily_burn_avg)




              monthly_burn = user.health.monthly_burn
              users = User.objects(Q(age__lte= user.age+3) & Q(age__gte = user.age-3) & Q(age__ne = None) & Q(health__ne = None)).order_by('health.monthly_burn')
              totalUsers = len(users)
              print totalUsers , 'totalUsers'
              for usr in users:
                  print 'usr.healt',usr.health.monthly_burn , usr.email , usr.health.peer_text
              betterUsers = 0
              usersDoingbeter = [user1 for user1 in users if getFloat(user1.health.monthly_burn)<=monthly_burn]
              betterUsers = len(usersDoingbeter)
              print 'better',betterUsers
            #  print (betterUsers/totalUsers) *100 , 'beta'
              user.health.saving_percentile = getFloat((getFloat(betterUsers)/getFloat(totalUsers)) *100) if totalUsers and betterUsers !=0 else 0.0
              print  user.health.saving_percentile , 'sabin'
        #      user.health.peer_daily_burn = 233.03
        #      print user.health.peer_daily_burn
              user.health.peer_text = self.peerRating(user.health.saving_percentile)
              print user.health.peer_text , 'usersd'
              print user.long_term_goals , 'future goals'
              print 'insightdate',user.insight_date
              user.save()

        def peerRating(self,percentage):
            if percentage<40.0:
                return 'You are in the top %.2f %% your peer group'% percentage
            else:
                return 'You are in the bottom %.2f %% of your peer group'% percentage
